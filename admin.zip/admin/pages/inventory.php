<?php
    include('../includes/header.php'); 
    include('../includes/navbar.php'); 
    $x = dirname(__FILE__).'/../../controller/processing.php';
    include($x);

  
    ?>

<?php

$obj = new Processing();


?>

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    

<!-- begininnig of adding new product -->
<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Products</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="product_form" autocomplete="off" onsubmit="return false">

        <div class="modal-body">

        <div class="form-group">
        <label for="subcatid"> Subcategory Name</label>
               <select class="form-control" name="subcatid" id="subcatid">
                 <option value="0">-- Subcateory Name --</option>
                <?php echo($obj->subcatDropdown()); ?>
               </select>
                <small id="scat_error" class="form-text text-muted"></small>
            </div>

            <div class="form-group">
                <label> Product Name </label>
                <input type="text" name="product_name" id="product_name" class="form-control" placeholder="eg. Fashforward">
                <small id="pn_error" class="form-text text-muted"></small>
              </div>

            <div class="form-group">
                <label> Product Price </label>
                <input type="text" name="product_price" id="product_price" class="form-control" placeholder="eg.100, 100.20">
                <small id="pp_error" class="form-text text-muted"></small>
              </div>
            <div class="form-group">
                <label>Quantity</label>
                <input type="number" name="product_qty" id="product_qty"  class="form-control" placeholder="eg.100">
                <small id="pq_error" class="form-text text-muted"></small>
              </div>

            <div class="form-group">
                <label>Product Color</label>
                <input type="text" name="product_color" id="product_color" class="form-control" placeholder="eg.Dashiki Skirt">
                <small id="pc_error" class="form-text text-muted"></small>
              </div>

            <div class="form-group">
                <label>Product Description</label>
                <input type="text" name="product_desc" id="product_desc" class="form-control" placeholder="eg.Dashiki Skirt">
                <small id="pd_error" class="form-text text-muted"></small>
               </div>
            
          

            <div class="form-group">
                <label>Tags</label>
                <input type="text"  id="product_tags" name="product_tags" class="form-control" placeholder="eg. Raffia prints">
                <small id="pt_error" class="form-text text-muted"></small>
              </div>

            <div class="form-group">
                <label for="upload">Select Image to Upload</label>
                <input type="text" name="product_img" id="product_img" class="form-control">
                <small id="pi_error" class="form-text text-muted"></small>
              </div>

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit"  class="btn btn-primary">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>

<!-- end of adding new product -->


<div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Product Management 
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
              Add +
            </button>
    </h6>
  </div>

  <div class="card-body">

    <div class="table-responsive">

      <table class="table table-bordered"  width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> Product Id </th>
            <th> Product Title</th>
            <th>Product price</th>
            <th>Quantity</th>
            <th>Color</th>
            <th>Product Tags</th>
            <th>EDIT </th>
            <th>DELETE </th>
          </tr>
        </thead>
        <tbody>
         <!-- Product Insertion  -->
         <tr>
          <?php echo($obj->productTable()); ?>
          </tr>
        </tbody>
      </table>

    </div>
  </div>
</div>

</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="../js/amain.js"></script>
 

  <?php
include('../includes/scripts.php');
// include('../includes/footer.php');
?>
