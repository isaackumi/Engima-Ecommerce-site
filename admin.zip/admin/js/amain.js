var DOMAIN = "http://localhost/enigma";
$(document).ready(function(){
    // $("#shopT").DataTable();
     // Admin Section 

    // Registration Validation and Processing 
    $("#adminregister_form").on("submit",function(){ 
        var admin_status = false;
        var admin_name = $("#admin_fullname");
        var admin_email = $("#admin_email");
        var admin_pass = $("#admin_password1");
        var admin_pass2 = $("#admin_password2");
        var security_code = $("#security_code");

        var n_patt = new RegExp(/^[A-Za-z ]+$/);
        var e_patt = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i;

        // Name Validation 
        if(admin_name.val() == "" || admin_name.val().length <= 3){
            admin_name.addClass("border-danger");
            $("#afn_error").html("<span class='text-danger'>Please enter Name and Name should be 3 characters long </span>");
            admin_status = false;
        }
        else{
            admin_name.removeClass("border-danger");
            $("#afn_error").html("");
            admin_status = true;
        }

        // Email Validation
        if(!e_patt.test(admin_email.val())){
            admin_email.addClass("border-danger");
            $("#ae_error").html("<span class='text-danger'>Please enter Valid Address</span>");
            admin_status = false;
        }
        else{
            admin_email.removeClass("border-danger");
            $("#ae_error").html("");
            admin_status = true;
        }

        // Password Validation 
        if(admin_pass.val() == "" || admin_pass.val().length < 5){
            admin_pass.addClass("border-danger");
            $("#ap1_error").html("<span class='text-danger'>Please enter more than 5 digit password</span>");
            admin_status = false;
        }
        else{
            admin_pass.removeClass("border-danger");
            $("#ap1_error").html("");
            admin_status = true;
        }


         // Password Validation 
        if(admin_pass2.val() == "" || admin_pass2.val().length < 5){
            admin_pass2.addClass("border-danger");
            $("#ap2_error").html("<span class='text-danger'>Please enter more than 5 digit password</span>");
            admin_status = false;
        }
        else{
            admin_pass2.removeClass("border-danger");
            $("#ap2_error").html("");
            admin_status = true;
        }

         // Security Code Validation 
        if(security_code.val()=="" || security_code.val().length<3){
            security_code.addClass("border-danger");
            $("#asc2_error").html("<span class='text-danger'>Please enter more than 3 digit code </span>");
            admin_status = false;
        }
        else{
            security_code.removeClass("border-danger");
            $("#asc2_error").html("");
            admin_status = true;
        }


        // Password Match 
        if(admin_pass.val() === admin_pass2.val() && admin_status == true & admin_pass.val() !== "" && admin_pass2.val() !== ""){

            // Transfer to process.php
            $.ajax({
                url: "http://localhost/enigma/controller/process.php",
                method: "POST",
                data: $("#adminregister_form").serialize(),
                success: function(data){
                    console.log("we move");
                    if(data == "ADMINSTRATOR_ALREADY_EXISTS"){
                        alert("it seems like your email is already being in  used");
                    }else if (data == "SOME_ERROR"){
                        alert("Something went wrong");
                    }
                    else{
                        // window.location.href= encodeURI(DOMAIN+"/admin/index.php?msg=You are registered Now you can login");
                    }

                }
            })
        }
        else{
            admin_pass2.removeClass("border-danger");
            $("#p2_error").html("<span class='text-danger'>Password mismatched</span>");
            status = true;
        }
        
        

    })





    // Admin Login Validation  and Processing 
     // Login Section 
     $("#admin_login_form").on("submit",function(){
      
        var admin_email = $("#admin_log_email");
        var admin_pass = $("#admin_log_pass");
        var admin_code = $("#admin_log_code");
        var admin_status = false;

        // Email Validation 
        if(admin_email.val() == ""){
            admin_email.addClass("border-danger");
            $("#e_error").html("<span class='text-danger'>Please enter your email </span>");
            admin_status = false;
        }else{
            admin_email.removeClass("border-danger");
            $("#e_error").html("");
            admin_status = true;
        }


        // Password Validation 
        if(admin_pass.val() == ""){
            admin_pass.addClass("border-danger");
            $("#p_error").html("<span class='text-danger'>Please enter your password </span>");
            status = false;
        }else{
            admin_pass.removeClass("border-danger");
            $("#p_error").html("");
            admin_status = true;
        }


        // Security Code Validation 
        if(admin_code.val() == ""){
            admin_code.addClass("border-danger");
            $("#sc_error").html("<span class='text-danger'>Please enter your security code</span>");
            status = false;
        }else{
            admin_pass.removeClass("border-danger");
            $("#sc_error").html("");
            admin_status = true;
        }


        if(admin_status){
            
            $.ajax({
                url: "http://localhost/enigma/controller/process.php",
                method: "POST",
                data: $("#admin_login_form").serialize(),
                success: function(data){
                    if(data == "NOT_REGISTERED"){
                        admin_email.addClass("border-danger");
                        $("#e_error").html("<span class='text-danger'>it seems like you are not registered</span>");
                    }else if(data == "PASSWORD_NOT_MATCHED"){
                        pass.addClass("border-danger");
                        $("#p_error").html("<span class='text-danger'>Password does not match</span>");
                    }
                    else{
                       console.log(data);
                        window.location.href= DOMAIN +"/admin/pages/dashboard.php";
                       
                   
                    }

                }
            })
        }
    })





    // Shop Validation 
    $("#shop_form").on("submit",function(){
        var status = false;
        var vendorid = $("#vendor_id")
        var shopname = $("#shop_name");
        var shopdesc = $("#shop_desc");
        var shopadd = $("#shop_add");
        var shop_logo = $("#shop_logo");
 
        var n_patt = new RegExp(/^[A-Za-z ]+$/);
        var e_patt = new RegExp(/^[a-z0-9_-]+(\.[a-z0-9_-])*@[a-z0-9_-]+(\.[a-z0-9_-]+)*(\.[a-z]{2,4})$/);

        // Shop Name Validation 
        if(shopname.val() == ""){
            shopname.addClass("border-danger");
            $("#sn_error").html("<span class='text-danger'>Please fill the shop name </span>");
            status = false;
        }
        else{
            shopname.removeClass("border-danger");
            $("#sn_error").html("");
            status = true;
        }

        // Shop Name Validation 
        if(vendorid.val() == "0"){
            vendorid.addClass("border-danger");
            $("#vsn_error").html("<span class='text-danger'>Please choose a vendor</span>");
            status = false;
        }
        else{
            vendorid.removeClass("border-danger");
            $("#vsn_error").html("");
            status = true;
        }


        // Shop Description Validation 
        if(shopdesc.val() == ""){
            shopdesc.addClass("border-danger");
            $("#sd_error").html("<span class='text-danger'>Please fill the shop description </span>");
            status = false;
        }
        else{
            shopdesc.removeClass("border-danger");
            $("#sd_error").html("");
            status = true;
        }


        // Shop Address Validation 
        if(shopadd.val() == ""){
            shopadd.addClass("border-danger");
            $("#sa_error").html("<span class='text-danger'>Please fill the shop address </span>");
            status = false;
        }
        else{
            shopadd.removeClass("border-danger");
            $("#sa_error").html("");
            status = true;
        }


         // Shop Image Validation 
         if(shop_logo.val() == ""){
            shop_logo.addClass("border-danger");
            $("#sl_error").html("<span class='text-danger'>Please select a logo </span>");
            status = false;
        }
        else{
            shop_logo.removeClass("border-danger");
            $("#sl_error").html("");
            status = true;
        }

        if(status == true){
            // Transfer to process.php {controller}
            $.ajax({
                url: DOMAIN+"/controller/process.php",
                method: "POST",
                data: $("#shop_form").serialize(),
                success: function(data){
                    if(data == "SHOP_CREATED"){
                        alert("it seems like your email is already being in  used");
                    }else if (data == "SOME_ERROR"){
                        alert("Something went wrong");
                    }
                    else{
                        window.location.href= encodeURI(DOMAIN+"/admin/pages/shop.php");
                    }
                    console.log(data);
                }
            })
        }
        else{
            status = true;
        }
    })




// Vendor Validation 
$("#vendor_form").on("submit",function(){
    var status = false;
    var vendorname = $("#vendor_name");
    var vendoremail = $("#vendor_email");
    var vendorphone = $("#vendor_phone");
    var vendorlocate = $("#vendor_location");
    var vendorcity = $("#vendor_city");


    var n_patt = new RegExp(/^[A-Za-z ]+$/);
    var e_patt = new RegExp(/^[a-z0-9_-]+(\.[a-z0-9_-])*@[a-z0-9_-]+(\.[a-z0-9_-]+)*(\.[a-z]{2,4})$/);

    // Vendor Name Validation 
    if(vendorname.val() == ""){
        vendorname.addClass("border-danger");
        $("#vn_error").html("<span class='text-danger'>Please fill the vendor name </span>");
        status = false;
    }
    else{
        vendorname.removeClass("border-danger");
        $("#vn_error").html("");
        status = true;
    }

    // Vendor Email Validation
    if(!e_patt.test(vendoremail.val())){
        vendoremail.addClass("border-danger");
        $("#ve_error").html("<span class='text-danger'>Please enter Valid Address</span>");
        status = false;
    }
    else{
        vendoremail.removeClass("border-danger");
        $("#ve_error").html("");
        status = true;
    }


    // Vendor Phone  Validation 
    if(vendorphone.val() == ""){
        vendorphone.addClass("border-danger");
        $("#vp_error").html("<span class='text-danger'>Please enter the vendor phone number  </span>");
        status = false;
    }
    else{
        vendorphone.removeClass("border-danger");
        $("#vp_error").html("");
        status = true;
    }

     // Vendor Country Validation 
     if(vendorlocate.val() == ""){
        vendorlocate.addClass("border-danger");
        $("#vl_error").html("<span class='text-danger'>Please fill the vendor country </span>");
        status = false;
    }
    else{
        vendorlocate.removeClass("border-danger");
        $("#vl_error").html("");
        status = true;
    }


     // Vendor City Validation 
     if(vendorcity.val() == ""){
        vendorcity.addClass("border-danger");
        $("#vcy_error").html("<span class='text-danger'>Please fill the vendor city</span>");
        status = false;
    }
    else{
        vendorcity.removeClass("border-danger");
        $("#vcy_error").html("");
        status = true;
    }


    if(status == true){

        // Transfer to process.php
        $.ajax({
            url: DOMAIN+"/controller/process.php",
            method: "POST",
            data: $("#vendor_form").serialize(),
            success: function(data){
                console.log("we move");
                if(data == "VENDOR_ALREADY_EXISTS"){
                    $("#vrp_error").html("<span class='text-danger'>"+ data +"</span>");
                }else if (data == "SOME_ERROR"){
                    $("#vrp_error").html("<span class='text-danger'>"+ data +"</span>");
                }
                else{
                    window.location.href= encodeURI(DOMAIN+"/admin/pages/vendor-register.php");
                }

            }
        })
    }
    else{
        $("#vrp_error").html("<span class='text-danger'>Insertion Failure</span>");
    }

})


// Category Check 
$("#category_form").on("submit",function(){
    var status = false;
    var shopid= $("#shop_id");
    var category_name= $("#cat_name");

     // Shop Name Validation 
     if(shopid.val() == "0"){
        shopid.addClass("border-danger");
        $("#shn_error").html("<span class='text-danger'>Please choose a shop</span>");
        status = false;
    }
    else{
        shopid.removeClass("border-danger");
        $("#shn_error").html("");
        status = true;
    }

    // Vendor Name Validation 
    if(category_name.val() == ""){
        category_name.addClass("border-danger");
        $("#catn_error").html("<span class='text-danger'>Please fill the category name </span>");
        status = false;
    }
    else{
        category_name.removeClass("border-danger");
        $("#catn_error").html("");
        status = true;
    }
    if(status == true){

        // Transfer to process.php
        $.ajax({
            url: DOMAIN+"/controller/process.php",
            method: "POST",
            data: $("#category_form").serialize(),
            success: function(data){
                console.log("we move");
                if(data == "CATEGORY_ALREADY_EXIST_IN_SHOP"){
                    $("#catn_error").html("<span class='text-danger'>"+ data +"</span>");
                }else if (data == "SOME_ERROR"){
                    $("#cat_error").html("<span class='text-danger'>"+ data +"</span>");
                }
                else{
                    window.location.href= encodeURI(DOMAIN+"/admin/pages/category.php");
                }

            }
        })
    }



    
})


// Subcategry Check
$("#subcat_form").on("submit",function(){
    var status = false;
    var subvendorid= $("#svendor_id");
    var subcat_name= $("#subcat_name");

     //  Vendor Validation 
     if(subvendorid.val() == "0"){
        subvendorid.addClass("border-danger");
        $("#vns_error").html("<span class='text-danger'>Please choose a Category</span>");
        status = false;
    }
    else{
        subvendorid.removeClass("border-danger");
        $("#vns_error").html("");
        status = true;
    }

    // Vendor Name Validation 
    if(subcat_name.val() == ""){
        subcat_name.addClass("border-danger");
        $("#cscs_error").html("<span class='text-danger'>Please fill the subcategory name </span>");
        status = false;
    }
    else{
        subcat_name.removeClass("border-danger");
        $("#scs_error").html("");
        status = true;
    }
    if(status == true){

        // Transfer to process.php
        $.ajax({
            url: DOMAIN+"/controller/process.php",
            method: "POST",
            data: $("#subcat_form").serialize(),
            success: function(data){
                console.log("we move");
                if(data == "CATEGORY_ALREADY_EXIST_IN_SHOP"){
                    $("#catn_error").html("<span class='text-danger'>"+ data +"</span>");
                }else if (data == "SOME_ERROR"){
                    $("#cat_error").html("<span class='text-danger'>"+ data +"</span>");
                }
                else{
                    window.location.href= encodeURI(DOMAIN+"/admin/pages/subcategory.php");
                }

            }
        })
    }


})


$("#shopdel_btn").click(function(){
    window.location.href= encodeURI(DOMAIN+"/admin/pages/shop.php");
})


// Shop Validation 
$("#product_form").on("submit",function(){
    var status = false;
    var subcat_name= $("#subcatid")
    var productname = $("#product_name");
    var productqty = $("#product_qty");
    var productprice = $("#product_price");
    var productcolor = $("#product_color");
    var productdesc = $("#product_desc");
    var producttags = $("#product_tags");
    var productimg = $("#product_img");

    var n_patt = new RegExp(/^[A-Za-z ]+$/);
    var e_patt = new RegExp(/^[a-z0-9_-]+(\.[a-z0-9_-])*@[a-z0-9_-]+(\.[a-z0-9_-]+)*(\.[a-z]{2,4})$/);


     //Subcategory Name Validation 
     if(subcat_name.val() == "0"){
        subcat_name.addClass("border-danger");
        $("#scat_error").html("<span class='text-danger'>Please choose a subcategory</span>");
        status = false;
    }
    else{
        subcat_name.removeClass("border-danger");
        $("#vsn_error").html("");
        status = true;
    }

    // Product Name Validation 
    if(productname.val() == ""){
        productname.addClass("border-danger");
        $("#pn_error").html("<span class='text-danger'>Please fill the product name </span>");
        status = false;
    }
    else{
        productname.removeClass("border-danger");
        $("#pn_error").html("");
        status = true;
    }


    // Product Price  Validation 
    if(productprice.val() == ""){
        productprice.addClass("border-danger");
        $("#pp_error").html("<span class='text-danger'>Please fill the Product price  </span>");
        status = false;
    }
    else{
        productprice.removeClass("border-danger");
        $("#pp_error").html("");
        status = true;
    }


    //Product Quantity Validation 
    if(productqty.val() == ""){
        productqty.addClass("border-danger");
        $("#pq_error").html("<span class='text-danger'>Please fill the product quantity</span>");
        status = false;
    }
    else{
        productqty.removeClass("border-danger");
        $("#pq_error").html("");
        status = true;
    }

    //Product Color Validation 
    if(productcolor.val() == ""){
        productcolor.addClass("border-danger");
        $("#pc_error").html("<span class='text-danger'>Please fill the product Color </span>");
        status = false;
    }
    else{
        productcolor.removeClass("border-danger");
        $("#pc_error").html("");
        status = true;
    }


     //Product Description Validation 
     if(productdesc.val() == ""){
        productdesc.addClass("border-danger");
        $("#pd_error").html("<span class='text-danger'>Please fill the product description</span>");
        status = false;
    }
    else{
        productdesc.removeClass("border-danger");
        $("#pd_error").html("");
        status = true;
    }




     //Product Tag Validation 
     if(producttags.val() == ""){
        producttags.addClass("border-danger");
        $("#pt_error").html("<span class='text-danger'>Please fill the product tags</span>");
        status = false;
    }
    else{
        producttags.removeClass("border-danger");
        $("#pt_error").html("");
        status = true;
    }



     // Shop Image Validation 
     if(productimg.val() == ""){
        productimg.addClass("border-danger");
        $("#pi_error").html("<span class='text-danger'>Please select a image</span>");
        status = false;
    }
    else{
        productimg.removeClass("border-danger");
        $("#pi_error").html("");
        status = true;
    }

    if(status == true){
        // Transfer to process.php {controller}
        $.ajax({
            url: DOMAIN+"/controller/process.php",
            method: "POST",
            data: $("#product_form").serialize(),
            success: function(data){
                if(data == "PRODUCT_CREATED"){
                    alert("it seems like your email is already being in  used");
                }else if (data == "SOME_ERROR"){
                    alert("Something went wrong");
                }
                else{
                    window.location.href= encodeURI(DOMAIN+"/admin/pages/inventory.php");
                }
                console.log(data);
            }
        })
    }
    else{
        status = true;
    }
})
  




})